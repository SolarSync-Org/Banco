--------------------------------------------------------

CREATE OR REPLACE PROCEDURE insert_t_country (
    p_name_country VARCHAR2
) AS
BEGIN
    INSERT INTO t_country (id_country, name_country)
    VALUES (SQ_t_country.NEXTVAL, p_name_country);
END;
/


BEGIN
    insert_t_country('Brazil');
    insert_t_country('Argentina');
    insert_t_country('Chile');
    insert_t_country('Egito');
    insert_t_country('Marrocos');
    insert_t_country('Gana');
    insert_t_country('Camar�es');
    insert_t_country('Congo');
    insert_t_country('Senegal');
    insert_t_country('Lib�ria');
END;
/

--------------------------------------------------------

CREATE OR REPLACE PROCEDURE insert_t_state (
    p_id_country  NUMBER,
    p_name_state  VARCHAR2
) AS
BEGIN
    INSERT INTO t_state (id_state, id_country, name_state)
    VALUES (SQ_t_state.NEXTVAL, p_id_country, p_name_state);
END;
/


BEGIN
    insert_t_state(1, 'S�o Paulo'); 
    insert_t_state(2, 'Buenos Aires'); 
    insert_t_state(3, 'Santiago'); 
    insert_t_state(4, 'Cairo'); 
    insert_t_state(5, 'Casablanca'); 
    insert_t_state(6, 'Accra'); 
    insert_t_state(7, 'Douala'); 
    insert_t_state(8, 'Brazzaville'); 
    insert_t_state(9, 'Dakar'); 
    insert_t_state(10, 'Monrovia'); 
    
END;
/

--------------------------------------------------------

CREATE OR REPLACE PROCEDURE insert_t_cities (
    p_id_state NUMBER,
    p_city_name VARCHAR2
) AS
BEGIN
    INSERT INTO t_cities (id_city, id_state, city_name)
    VALUES (SQ_t_cities.NEXTVAL, p_id_state, p_city_name);
END;
/

BEGIN
    -- Cidades em S�o Paulo, Brasil
    insert_t_cities(1, 'Campinas');
    
    -- Cidades em Buenos Aires, Argentina
    insert_t_cities(2, 'La Plata');

    -- Cidades em Santiago, Chile
    insert_t_cities(3, 'Maip�');

    -- Cidades em Cairo, Egito
    insert_t_cities(4, 'Giza');

    -- Cidades em Casablanca, Marrocos
    insert_t_cities(5, 'Mohammedia');

    -- Cidades em Accra, Gana
    insert_t_cities(6, 'Tema');

    -- Cidades em Douala, Camar�es
    insert_t_cities(7, 'Ed�a');
    
    -- Cidades em Brazzaville, Congo
    insert_t_cities(8, 'Oyo');
    
    -- Cidades em Dakar, Senegal
    insert_t_cities(9, 'Gu�diawaye');
    
    -- Cidades em Monrovia, Lib�ria
    insert_t_cities(10, 'Paynesville');
END;
/

--------------------------------------------------------

CREATE OR REPLACE PROCEDURE insert_t_address (
    p_id_city      NUMBER,
    p_street       VARCHAR2,
    p_number       NUMBER,
    p_complement   VARCHAR2,
    p_neighborhood VARCHAR2,
    p_zip_code     VARCHAR2
) AS
BEGIN
    INSERT INTO t_address (id_address, id_city, street, "NUMBER", complement, neighborhood, zip_code)
    VALUES (SQ_t_address.NEXTVAL, p_id_city, p_street, p_number, p_complement, p_neighborhood, p_zip_code);
END;
/


BEGIN
    -- Endere�os em Campinas, S�o Paulo, Brasil
    insert_t_address(1, 'Avenida Brasil', 100, 'Apt 502', 'Centro', '13000-100');

    -- Endere�os em La Plata, Buenos Aires, Argentina
    insert_t_address(2, 'Calle 13', 150, 'Casa 2', 'Centro', 'B1900-XYZ');

    -- Endere�os em Maip�, Santiago, Chile
    insert_t_address(3, 'Avenida Central', 300, 'Depto 101', 'Maip�', '7500000');

    -- Endere�os em Giza, Cairo, Egito
    insert_t_address(4, 'Pyramid Road', 500, 'Suite 10', 'Giza', '12561');

    -- Endere�os em Mohammedia, Casablanca, Marrocos
    insert_t_address(5, 'Boulevard de la Corniche', 700, 'Flat 5', 'Mohammedia', '28800');

    -- Endere�os em Tema, Accra, Gana
    insert_t_address(6, 'Independence Avenue', 900, 'Unit 9', 'Tema', 'GA1111');
    
    -- Endere�os em Ed�a, Douala, Camar�es
    insert_t_address(7, 'Boulevard de la Libert�', 1100, 'Penthouse', 'Ed�a', 'DOU0100');

    -- Endere�os em Oyo, Brazzaville, Congo
    insert_t_address(8, 'Route N2', 1300, 'Suite A', 'Oyo', 'CNG0100');

    -- Endere�os em Gu�diawaye, Dakar, Senegal
    insert_t_address(9, 'Avenue Cheikh Anta Diop', 1500, 'Office 301', 'Gu�diawaye', 'DKR1000');

    -- Endere�os em Paynesville, Monrovia, Lib�ria
    insert_t_address(10, 'Broad Street', 1700, 'Apt 202', 'Paynesville', 'ML1000');
END;
/

--------------------------------------------------------

CREATE OR REPLACE PROCEDURE insert_t_type_property (
    p_tp_residence VARCHAR2
) AS
BEGIN
    INSERT INTO t_type_property (id_tp_property, tp_residence)
    VALUES (SQ_t_type_property.NEXTVAL, p_tp_residence);
END;
/


BEGIN
    insert_t_type_property('Apartment');
    insert_t_type_property('House');
    insert_t_type_property('Condominium');
    insert_t_type_property('Townhouse');
    insert_t_type_property('Studio');
    insert_t_type_property('Loft');
    insert_t_type_property('Villa');
    insert_t_type_property('Cottage');
    insert_t_type_property('Duplex');
    insert_t_type_property('Bungalow');
END;
/

--------------------------------------------------------

CREATE OR REPLACE PROCEDURE insert_t_type_service (
    p_solutions VARCHAR2
) AS
BEGIN
    INSERT INTO t_type_service (id_tp_service, solutions)
    VALUES (SQ_t_type_service.NEXTVAL, p_solutions);
END;
/


BEGIN
    insert_t_type_service('Cleaning');
    insert_t_type_service('Plumbing');
    insert_t_type_service('Electricity');
    insert_t_type_service('Gardening');
    insert_t_type_service('Pest Control');
    insert_t_type_service('Security');
    insert_t_type_service('Catering');
    insert_t_type_service('Maintenance');
    insert_t_type_service('IT Support');
    insert_t_type_service('Consulting');
END;
/

--------------------------------------------------------

CREATE OR REPLACE PROCEDURE insert_t_regions (
    p_coverage_area VARCHAR2
) AS
BEGIN
    INSERT INTO t_regions (id_regions, coverage_area)
    VALUES (SQ_t_regions.NEXTVAL, p_coverage_area);
END;
/


BEGIN
    insert_t_regions('North America');
    insert_t_regions('South America');
    insert_t_regions('Europe');
    insert_t_regions('Asia');
    insert_t_regions('Africa');
    insert_t_regions('Oceania');
    insert_t_regions('Middle East');
    insert_t_regions('Central America');
    insert_t_regions('Caribbean');
    insert_t_regions('Antarctica');
END;
/

--------------------------------------------------------

CREATE OR REPLACE PROCEDURE insert_t_client (
    p_id_address     NUMBER,
    p_id_tp_property NUMBER,
    p_client_name    VARCHAR2,
    p_birth_date     DATE,
    p_cpf            NUMBER,
    p_email_client   VARCHAR2,
    p_phone_client   VARCHAR2,
    p_rent           CHAR
) AS
BEGIN
    INSERT INTO t_client (id_client, id_address, id_tp_property, client_name, birth_date, cpf, email_client, phone_client, rent)
    VALUES (SQ_t_client.NEXTVAL, p_id_address, p_id_tp_property, p_client_name, p_birth_date, p_cpf, p_email_client, p_phone_client, p_rent);
END;
/


BEGIN
    -- Cliente 1
    insert_t_client(1, 1, 'Lucas Silva', TO_DATE('1990-05-15', 'YYYY-MM-DD'), 12345678900, 'lucas.silva@example.com', '123-456-7890', 'N');
    
    -- Cliente 2
    insert_t_client(2, 2, 'Mariana Costa', TO_DATE('1985-07-22', 'YYYY-MM-DD'), 98765432100, 'mariana.costa@example.com', '098-765-4321', 'Y');
    
    -- Cliente 3
    insert_t_client(3, 3, 'J�lia Pereira', TO_DATE('1992-11-30', 'YYYY-MM-DD'), 11223344556, 'julia.pereira@example.com', '112-233-4455', 'N');
    
    -- Cliente 4
    insert_t_client(4, 4, 'Carlos Alberto', TO_DATE('1975-02-10', 'YYYY-MM-DD'), 55667788990, 'carlos.alberto@example.com', '223-344-5566', 'Y');
    
    -- Cliente 5
    insert_t_client(5, 5, 'Ana Paula', TO_DATE('1988-03-05', 'YYYY-MM-DD'), 99887766554, 'ana.paula@example.com', '334-455-6677', 'N');

    -- Cliente 6
    insert_t_client(6, 6, 'Fernando Oliveira', TO_DATE('1980-08-13', 'YYYY-MM-DD'), 33445566778, 'fernando.oliveira@example.com', '445-566-7788', 'Y');

    -- Cliente 7
    insert_t_client(7, 7, 'Beatriz Mendes', TO_DATE('1995-12-21', 'YYYY-MM-DD'), 66778899001, 'beatriz.mendes@example.com', '556-677-8899', 'N');

    -- Cliente 8
    insert_t_client(8, 8, 'Rafael Gomes', TO_DATE('1983-04-09', 'YYYY-MM-DD'), 44556677889, 'rafael.gomes@example.com', '667-788-9900', 'Y');

    -- Cliente 9
    insert_t_client(9, 9, 'Carla Ferreira', TO_DATE('1991-06-18', 'YYYY-MM-DD'), 77889900112, 'carla.ferreira@example.com', '778-899-0011', 'N');

    -- Cliente 10
    insert_t_client(10, 10, 'Marcelo Lima', TO_DATE('1989-09-29', 'YYYY-MM-DD'), 88990011223, 'marcelo.lima@example.com', '889-001-1223', 'Y');
END;
/

--------------------------------------------------------

CREATE OR REPLACE PROCEDURE insert_t_monthly_consumption (
    p_id_client          NUMBER,
    p_energy_consumption NUMBER,
    p_month_registration DATE
) AS
BEGIN
    INSERT INTO t_monthly_consumption (id_consumption, id_client, energy_consumption, month_registration)
    VALUES (SQ_t_monthly_consumption.NEXTVAL, p_id_client, p_energy_consumption, p_month_registration);
END;
/


BEGIN
    -- Consumo do Cliente 1 em Janeiro de 2024
    insert_t_monthly_consumption(1, 320.5, TO_DATE('2024-01-01', 'YYYY-MM-DD'));

    -- Consumo do Cliente 2 em Fevereiro de 2024
    insert_t_monthly_consumption(2, 450.75, TO_DATE('2024-02-01', 'YYYY-MM-DD'));

    -- Consumo do Cliente 3 em Mar�o de 2024
    insert_t_monthly_consumption(3, 500.0, TO_DATE('2024-03-01', 'YYYY-MM-DD'));

    -- Consumo do Cliente 4 em Abril de 2024
    insert_t_monthly_consumption(4, 600.25, TO_DATE('2024-04-01', 'YYYY-MM-DD'));

    -- Consumo do Cliente 5 em Maio de 2024
    insert_t_monthly_consumption(5, 550.0, TO_DATE('2024-05-01', 'YYYY-MM-DD'));

    -- Consumo do Cliente 6 em Junho de 2024
    insert_t_monthly_consumption(6, 470.3, TO_DATE('2024-06-01', 'YYYY-MM-DD'));

    -- Consumo do Cliente 7 em Julho de 2024
    insert_t_monthly_consumption(7, 520.6, TO_DATE('2024-07-01', 'YYYY-MM-DD'));

    -- Consumo do Cliente 8 em Agosto de 2024
    insert_t_monthly_consumption(8, 610.4, TO_DATE('2024-08-01', 'YYYY-MM-DD'));

    -- Consumo do Cliente 9 em Setembro de 2024
    insert_t_monthly_consumption(9, 580.9, TO_DATE('2024-09-01', 'YYYY-MM-DD'));

    -- Consumo do Cliente 10 em Outubro de 2024
    insert_t_monthly_consumption(10, 490.2, TO_DATE('2024-10-01', 'YYYY-MM-DD'));
END;
/

--------------------------------------------------------

CREATE OR REPLACE PROCEDURE insert_t_company (
    p_id_address     NUMBER,
    p_id_regions     NUMBER,
    p_id_tp_property NUMBER,
    p_company_name   VARCHAR2,
    p_cnpj           NUMBER,
    p_email_company  VARCHAR2,
    p_phone_company  VARCHAR2
) AS
BEGIN
    INSERT INTO t_company (id_company, id_address, id_regions, id_tp_property, company_name, cnpj, email_company, phone_company)
    VALUES (SQ_t_company.NEXTVAL, p_id_address, p_id_regions, p_id_tp_property, p_company_name, p_cnpj, p_email_company, p_phone_company);
END;
/


BEGIN
    -- Empresa 1
    insert_t_company(1, 1, 1, 'TechCorp', 12345678910, 'contact@techcorp.com', '123-456-7890');

    -- Empresa 2
    insert_t_company(2, 2, 2, 'EcoSolutions', 12345678910, 'info@ecosolutions.com', '098-765-4321');

    -- Empresa 3
    insert_t_company(3, 3, 3, 'Foodies', 12345678910, 'hello@foodies.com', '112-233-4455');

    -- Empresa 4
    insert_t_company(4, 4, 4, 'TravelWise', 12345678910, 'support@travelwise.com', '223-344-5566');

    -- Empresa 5
    insert_t_company(5, 5, 5, 'HealthPlus', 12345678910, 'contact@healthplus.com', '334-455-6677');
    
    -- Empresa 6
    insert_t_company(6, 6, 6, 'BrightFuture', 12345678910, 'contact@brightfuture.com', '445-566-7788');

    -- Empresa 7
    insert_t_company(7, 7, 7, 'EduWorld', 12345678910, 'info@eduworld.com', '556-677-8899');

    -- Empresa 8
    insert_t_company(8, 8, 8, 'Innovatech', 12345678910, 'support@innovatech.com', '667-788-9900');

    -- Empresa 9
    insert_t_company(9, 9, 9, 'GreenLeaf', 12345678910, 'hello@greenleaf.com', '778-899-0011');

    -- Empresa 10
    insert_t_company(10, 10, 10, 'SafeGuard', 12345678910, 'contact@safeguard.com', '889-001-1223');
END;
/

--------------------------------------------------------

CREATE OR REPLACE PROCEDURE insert_t_services (
    p_id_client     NUMBER,
    p_id_company    NUMBER,
    p_id_tp_service NUMBER,
    p_type_user     VARCHAR2
) AS
BEGIN
    INSERT INTO t_services (id_service, id_client, id_company, id_tp_service, type_user)
    VALUES (SQ_t_services.NEXTVAL, p_id_client, p_id_company, p_id_tp_service, p_type_user);
END;
/


BEGIN
    -- Servi�o para Cliente 1, Empresa 1, Tipo de Servi�o 1
    insert_t_services(1, 1, 1, 'Residential');

    -- Servi�o para Cliente 2, Empresa 2, Tipo de Servi�o 2
    insert_t_services(2, 2, 2, 'Commercial');

    -- Servi�o para Cliente 3, Empresa 3, Tipo de Servi�o 3
    insert_t_services(3, 3, 3, 'Industrial');

    -- Servi�o para Cliente 4, Empresa 4, Tipo de Servi�o 4
    insert_t_services(4, 4, 4, 'Government');

    -- Servi�o para Cliente 5, Empresa 5, Tipo de Servi�o 5
    insert_t_services(5, 5, 5, 'Non-profit');
    
    -- Servi�o para Cliente 6, Empresa 6, Tipo de Servi�o 1
    insert_t_services(6, 6, 6, 'Residential');

    -- Servi�o para Cliente 7, Empresa 7, Tipo de Servi�o 2
    insert_t_services(7, 7, 7, 'Commercial');

    -- Servi�o para Cliente 8, Empresa 8, Tipo de Servi�o 3
    insert_t_services(8, 8, 8, 'Industrial');

    -- Servi�o para Cliente 9, Empresa 9, Tipo de Servi�o 4
    insert_t_services(9, 9, 9, 'Government');

    -- Servi�o para Cliente 10, Empresa 10, Tipo de Servi�o 5
    insert_t_services(10, 10, 10, 'Non-profit');
END;
/

--------------------------------------------------------
--SELECT
SELECT * FROM T_COUNTRY;
SELECT * FROM T_STATE;
SELECT * FROM T_CITIES;
SELECT * FROM T_ADDRESS;
SELECT * FROM T_CLIENT;
SELECT * FROM T_COMPANY;
SELECT * FROM T_SERVICES;
SELECT * FROM T_MONTHLY_CONSUMPTION;
SELECT * FROM T_TYPE_PROPERTY;
SELECT * FROM T_TYPE_SERVICE;
SELECT * FROM T_REGIONS;

SELECT * FROM audit_log;

--------------------------------------------------------

--Criar uma procedure para exportar um dataset no formato JSON.

CREATE OR REPLACE PROCEDURE export_full_data_to_json IS
    v_json_output CLOB;
BEGIN
    SELECT JSON_ARRAYAGG(
             JSON_OBJECT(
                 'service' VALUE JSON_OBJECT(
                     'id_service' VALUE s.id_service,
                     'id_client' VALUE s.id_client,
                     'id_company' VALUE s.id_company,
                     'id_tp_service' VALUE s.id_tp_service,
                     'type_user' VALUE s.type_user
                 ),
                 'client' VALUE JSON_OBJECT(
                     'id_client' VALUE c.id_client,
                     'id_address' VALUE c.id_address,
                     'id_tp_property' VALUE c.id_tp_property,
                     'client_name' VALUE c.client_name,
                     'birth_date' VALUE TO_CHAR(c.birth_date, 'YYYY-MM-DD'),
                     'cpf' VALUE c.cpf,
                     'email_client' VALUE c.email_client,
                     'phone_client' VALUE c.phone_client,
                     'rent' VALUE c.rent
                 ),
                 'company' VALUE JSON_OBJECT(
                     'id_company' VALUE comp.id_company,
                     'id_address' VALUE comp.id_address,
                     'id_regions' VALUE comp.id_regions,
                     'id_tp_property' VALUE comp.id_tp_property,
                     'company_name' VALUE comp.company_name,
                     'cnpj' VALUE comp.cnpj,
                     'email_company' VALUE comp.email_company,
                     'phone_company' VALUE comp.phone_company
                 )
             )
           ) INTO v_json_output
    FROM t_services s
    JOIN t_client c ON s.id_client = c.id_client
    JOIN t_company comp ON s.id_company = comp.id_company;

    -- Exibir o JSON resultante
    DBMS_OUTPUT.PUT_LINE(v_json_output);

    -- Adicione l�gica adicional aqui para salvar ou manipular o JSON conforme necess�rio
END export_full_data_to_json;
/

