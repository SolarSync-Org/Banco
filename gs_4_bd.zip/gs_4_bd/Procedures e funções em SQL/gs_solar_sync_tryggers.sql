--Tabela auditoria criada no arquivo "gs_solar_sync_cria.sql"

-------------------------------------------------------------------------
--Trigger para t_country

CREATE OR REPLACE TRIGGER trg_audit_t_country
AFTER INSERT OR UPDATE OR DELETE ON t_country
FOR EACH ROW
DECLARE
    v_affected_row CLOB;
    v_operation VARCHAR2(10);
BEGIN
    IF INSERTING THEN
        v_operation := 'INSERT';
        v_affected_row := '{' ||
                          '"id_country": ' || :NEW.id_country || ',' ||
                          '"name_country": "' || :NEW.name_country || '"' ||
                          '}';
    ELSIF UPDATING THEN
        v_operation := 'UPDATE';
        v_affected_row := '{' ||
                          '"id_country": ' || :NEW.id_country || ',' ||
                          '"name_country": "' || :NEW.name_country || '"' ||
                          '}';
    ELSIF DELETING THEN
        v_operation := 'DELETE';
        v_affected_row := '{' ||
                          '"id_country": ' || :OLD.id_country || ',' ||
                          '"name_country": "' || :OLD.name_country || '"' ||
                          '}';
    END IF;

    INSERT INTO audit_log (audit_id, table_name, operation, affected_row)
    VALUES (
        SQ_audit_log.NEXTVAL,
        't_country',
        v_operation,
        v_affected_row
    );
END trg_audit_t_country;
/
-------------------------------------------------------------------------
--Trigger para t_state

CREATE OR REPLACE TRIGGER trg_audit_t_state
AFTER INSERT OR UPDATE OR DELETE ON t_state
FOR EACH ROW
DECLARE
    v_affected_row CLOB;
    v_operation VARCHAR2(10);
BEGIN
    IF INSERTING THEN
        v_operation := 'INSERT';
        v_affected_row := '{' ||
                          '"id_state": ' || :NEW.id_state || ',' ||
                          '"id_country": ' || :NEW.id_country || ',' ||
                          '"name_state": "' || :NEW.name_state || '"' ||
                          '}';
    ELSIF UPDATING THEN
        v_operation := 'UPDATE';
        v_affected_row := '{' ||
                          '"id_state": ' || :NEW.id_state || ',' ||
                          '"id_country": ' || :NEW.id_country || ',' ||
                          '"name_state": "' || :NEW.name_state || '"' ||
                          '}';
    ELSIF DELETING THEN
        v_operation := 'DELETE';
        v_affected_row := '{' ||
                          '"id_state": ' || :OLD.id_state || ',' ||
                          '"id_country": ' || :OLD.id_country || ',' ||
                          '"name_state": "' || :OLD.name_state || '"' ||
                          '}';
    END IF;

    INSERT INTO audit_log (audit_id, table_name, operation, affected_row)
    VALUES (
        SQ_audit_log.NEXTVAL,
        't_state',
        v_operation,
        v_affected_row
    );
END trg_audit_t_state;
/

-------------------------------------------------------------------------
--Trigger para t_cities

CREATE OR REPLACE TRIGGER trg_audit_t_cities
AFTER INSERT OR UPDATE OR DELETE ON t_cities
FOR EACH ROW
DECLARE
    v_affected_row CLOB;
    v_operation VARCHAR2(10);
BEGIN
    IF INSERTING THEN
        v_operation := 'INSERT';
        v_affected_row := '{' ||
                          '"id_city": ' || :NEW.id_city || ',' ||
                          '"id_state": ' || :NEW.id_state || ',' ||
                          '"city_name": "' || :NEW.city_name || '"' ||
                          '}';
    ELSIF UPDATING THEN
        v_operation := 'UPDATE';
        v_affected_row := '{' ||
                          '"id_city": ' || :NEW.id_city || ',' ||
                          '"id_state": ' || :NEW.id_state || ',' ||
                          '"city_name": "' || :NEW.city_name || '"' ||
                          '}';
    ELSIF DELETING THEN
        v_operation := 'DELETE';
        v_affected_row := '{' ||
                          '"id_city": ' || :OLD.id_city || ',' ||
                          '"id_state": ' || :OLD.id_state || ',' ||
                          '"city_name": "' || :OLD.city_name || '"' ||
                          '}';
    END IF;

    INSERT INTO audit_log (audit_id, table_name, operation, affected_row)
    VALUES (
        SQ_audit_log.NEXTVAL,
        't_cities',
        v_operation,
        v_affected_row
    );
END trg_audit_t_cities;
/

-------------------------------------------------------------------------
--Trigger para t_address

CREATE OR REPLACE TRIGGER trg_audit_t_address
AFTER INSERT OR UPDATE OR DELETE ON t_address
FOR EACH ROW
DECLARE
    v_affected_row CLOB;
    v_operation VARCHAR2(10);
BEGIN
    IF INSERTING THEN
        v_operation := 'INSERT';
        v_affected_row := '{' ||
                          '"id_address": ' || :NEW.id_address || ',' ||
                          '"id_city": ' || :NEW.id_city || ',' ||
                          '"street": "' || :NEW.street || '",' ||
                          '"number": ' || :NEW."NUMBER" || ',' ||
                          '"complement": "' || :NEW.complement || '",' ||
                          '"neighborhood": "' || :NEW.neighborhood || '",' ||
                          '"zip_code": "' || :NEW.zip_code || '"' ||
                          '}';
    ELSIF UPDATING THEN
        v_operation := 'UPDATE';
        v_affected_row := '{' ||
                          '"id_address": ' || :NEW.id_address || ',' ||
                          '"id_city": ' || :NEW.id_city || ',' ||
                          '"street": "' || :NEW.street || '",' ||
                          '"number": ' || :NEW."NUMBER" || ',' ||
                          '"complement": "' || :NEW.complement || '",' ||
                          '"neighborhood": "' || :NEW.neighborhood || '",' ||
                          '"zip_code": "' || :NEW.zip_code || '"' ||
                          '}';
    ELSIF DELETING THEN
        v_operation := 'DELETE';
        v_affected_row := '{' ||
                          '"id_address": ' || :OLD.id_address || ',' ||
                          '"id_city": ' || :OLD.id_city || ',' ||
                          '"street": "' || :OLD.street || '",' ||
                          '"number": ' || :OLD."NUMBER" || ',' ||
                          '"complement": "' || :OLD.complement || '",' ||
                          '"neighborhood": "' || :OLD.neighborhood || '",' ||
                          '"zip_code": "' || :OLD.zip_code || '"' ||
                          '}';
    END IF;

    INSERT INTO audit_log (audit_id, table_name, operation, affected_row)
    VALUES (
        SQ_audit_log.NEXTVAL,
        't_address',
        v_operation,
        v_affected_row
    );
END trg_audit_t_address;
/

-------------------------------------------------------------------------
--Trigger para t_type_property

CREATE OR REPLACE TRIGGER trg_audit_t_type_property
AFTER INSERT OR UPDATE OR DELETE ON t_type_property
FOR EACH ROW
DECLARE
    v_affected_row CLOB;
    v_operation VARCHAR2(10);
BEGIN
    IF INSERTING THEN
        v_operation := 'INSERT';
        v_affected_row := '{' ||
                          '"id_tp_property": ' || :NEW.id_tp_property || ',' ||
                          '"tp_residence": "' || :NEW.tp_residence || '"' ||
                          '}';
    ELSIF UPDATING THEN
        v_operation := 'UPDATE';
        v_affected_row := '{' ||
                          '"id_tp_property": ' || :NEW.id_tp_property || ',' ||
                          '"tp_residence": "' || :NEW.tp_residence || '"' ||
                          '}';
    ELSIF DELETING THEN
        v_operation := 'DELETE';
        v_affected_row := '{' ||
                          '"id_tp_property": ' || :OLD.id_tp_property || ',' ||
                          '"tp_residence": "' || :OLD.tp_residence || '"' ||
                          '}';
    END IF;

    INSERT INTO audit_log (audit_id, table_name, operation, affected_row)
    VALUES (
        SQ_audit_log.NEXTVAL,
        't_type_property',
        v_operation,
        v_affected_row
    );
END trg_audit_t_type_property;
/

-------------------------------------------------------------------------
--Trigger para t_type_service

CREATE OR REPLACE TRIGGER trg_audit_t_type_service
AFTER INSERT OR UPDATE OR DELETE ON t_type_service
FOR EACH ROW
DECLARE
    v_affected_row CLOB;
    v_operation VARCHAR2(10);
BEGIN
    IF INSERTING THEN
        v_operation := 'INSERT';
        v_affected_row := '{' ||
                          '"id_tp_service": ' || :NEW.id_tp_service || ',' ||
                          '"solutions": "' || :NEW.solutions || '"' ||
                          '}';
    ELSIF UPDATING THEN
        v_operation := 'UPDATE';
        v_affected_row := '{' ||
                          '"id_tp_service": ' || :NEW.id_tp_service || ',' ||
                          '"solutions": "' || :NEW.solutions || '"' ||
                          '}';
    ELSIF DELETING THEN
        v_operation := 'DELETE';
        v_affected_row := '{' ||
                          '"id_tp_service": ' || :OLD.id_tp_service || ',' ||
                          '"solutions": "' || :OLD.solutions || '"' ||
                          '}';
    END IF;

    INSERT INTO audit_log (audit_id, table_name, operation, affected_row)
    VALUES (
        SQ_audit_log.NEXTVAL,
        't_type_service',
        v_operation,
        v_affected_row
    );
END trg_audit_t_type_service;
/

-------------------------------------------------------------------------
--Trigger para t_regions

CREATE OR REPLACE TRIGGER trg_audit_t_regions
AFTER INSERT OR UPDATE OR DELETE ON t_regions
FOR EACH ROW
DECLARE
    v_affected_row CLOB;
    v_operation VARCHAR2(10);
BEGIN
    IF INSERTING THEN
        v_operation := 'INSERT';
        v_affected_row := '{' ||
                          '"id_regions": ' || :NEW.id_regions || ',' ||
                          '"coverage_area": "' || :NEW.coverage_area || '"' ||
                          '}';
    ELSIF UPDATING THEN
        v_operation := 'UPDATE';
        v_affected_row := '{' ||
                          '"id_regions": ' || :NEW.id_regions || ',' ||
                          '"coverage_area": "' || :NEW.coverage_area || '"' ||
                          '}';
    ELSIF DELETING THEN
        v_operation := 'DELETE';
        v_affected_row := '{' ||
                          '"id_regions": ' || :OLD.id_regions || ',' ||
                          '"coverage_area": "' || :OLD.coverage_area || '"' ||
                          '}';
    END IF;

    INSERT INTO audit_log (audit_id, table_name, operation, affected_row)
    VALUES (
        SQ_audit_log.NEXTVAL,
        't_regions',
        v_operation,
        v_affected_row
    );
END trg_audit_t_regions;
/

-------------------------------------------------------------------------
--Trigger para t_client

CREATE OR REPLACE TRIGGER trg_audit_t_client
AFTER INSERT OR UPDATE OR DELETE ON t_client
FOR EACH ROW
DECLARE
    v_affected_row CLOB;
    v_operation VARCHAR2(10);
BEGIN
    IF INSERTING THEN
        v_operation := 'INSERT';
        v_affected_row := '{' ||
                          '"id_client": ' || :NEW.id_client || ',' ||
                          '"id_address": ' || :NEW.id_address || ',' ||
                          '"id_tp_property": ' || :NEW.id_tp_property || ',' ||
                          '"client_name": "' || :NEW.client_name || '",' ||
                          '"birth_date": "' || TO_CHAR(:NEW.birth_date, 'YYYY-MM-DD') || '",' ||
                          '"cpf": ' || :NEW.cpf || ',' ||
                          '"email_client": "' || :NEW.email_client || '",' ||
                          '"phone_client": "' || :NEW.phone_client || '",' ||
                          '"rent": "' || :NEW.rent || '"' ||
                          '}';
    ELSIF UPDATING THEN
        v_operation := 'UPDATE';
        v_affected_row := '{' ||
                          '"id_client": ' || :NEW.id_client || ',' ||
                          '"id_address": ' || :NEW.id_address || ',' ||
                          '"id_tp_property": ' || :NEW.id_tp_property || ',' ||
                          '"client_name": "' || :NEW.client_name || '",' ||
                          '"birth_date": "' || TO_CHAR(:NEW.birth_date, 'YYYY-MM-DD') || '",' ||
                          '"cpf": ' || :NEW.cpf || ',' ||
                          '"email_client": "' || :NEW.email_client || '",' ||
                          '"phone_client": "' || :NEW.phone_client || '",' ||
                          '"rent": "' || :NEW.rent || '"' ||
                          '}';
    ELSIF DELETING THEN
        v_operation := 'DELETE';
        v_affected_row := '{' ||
                          '"id_client": ' || :OLD.id_client || ',' ||
                          '"id_address": ' || :OLD.id_address || ',' ||
                          '"id_tp_property": ' || :OLD.id_tp_property || ',' ||
                          '"client_name": "' || :OLD.client_name || '",' ||
                          '"birth_date": "' || TO_CHAR(:OLD.birth_date, 'YYYY-MM-DD') || '",' ||
                          '"cpf": ' || :OLD.cpf || ',' ||
                          '"email_client": "' || :OLD.email_client || '",' ||
                          '"phone_client": "' || :OLD.phone_client || '",' ||
                          '"rent": "' || :OLD.rent || '"' ||
                          '}';
    END IF;

    INSERT INTO audit_log (audit_id, table_name, operation, affected_row)
    VALUES (
        SQ_audit_log.NEXTVAL,
        't_client',
        v_operation,
        v_affected_row
    );
END trg_audit_t_client;
/

-------------------------------------------------------------------------
--Trigger para t_monthly_consumption

CREATE OR REPLACE TRIGGER trg_audit_t_monthly_consumption
AFTER INSERT OR UPDATE OR DELETE ON t_monthly_consumption
FOR EACH ROW
DECLARE
    v_affected_row CLOB;
    v_operation VARCHAR2(10);
BEGIN
    IF INSERTING THEN
        v_operation := 'INSERT';
        v_affected_row := '{' ||
                          '"id_consumption": ' || :NEW.id_consumption || ',' ||
                          '"id_client": ' || :NEW.id_client || ',' ||
                          '"energy_consumption": ' || :NEW.energy_consumption || ',' ||
                          '"month_registration": "' || TO_CHAR(:NEW.month_registration, 'YYYY-MM-DD') || '"' ||
                          '}';
    ELSIF UPDATING THEN
        v_operation := 'UPDATE';
        v_affected_row := '{' ||
                          '"id_consumption": ' || :NEW.id_consumption || ',' ||
                          '"id_client": ' || :NEW.id_client || ',' ||
                          '"energy_consumption": ' || :NEW.energy_consumption || ',' ||
                          '"month_registration": "' || TO_CHAR(:NEW.month_registration, 'YYYY-MM-DD') || '"' ||
                          '}';
    ELSIF DELETING THEN
        v_operation := 'DELETE';
        v_affected_row := '{' ||
                          '"id_consumption": ' || :OLD.id_consumption || ',' ||
                          '"id_client": ' || :OLD.id_client || ',' ||
                          '"energy_consumption": ' || :OLD.energy_consumption || ',' ||
                          '"month_registration": "' || TO_CHAR(:OLD.month_registration, 'YYYY-MM-DD') || '"' ||
                          '}';
    END IF;

    INSERT INTO audit_log (audit_id, table_name, operation, affected_row)
    VALUES (
        SQ_audit_log.NEXTVAL,
        't_monthly_consumption',
        v_operation,
        v_affected_row
    );
END trg_audit_t_monthly_consumption;
/

-------------------------------------------------------------------------
--Trigger para t_company

CREATE OR REPLACE TRIGGER trg_audit_t_company
AFTER INSERT OR UPDATE OR DELETE ON t_company
FOR EACH ROW
DECLARE
    v_affected_row CLOB;
    v_operation VARCHAR2(10);
BEGIN
    IF INSERTING THEN
        v_operation := 'INSERT';
        v_affected_row := '{' ||
                          '"id_company": ' || :NEW.id_company || ',' ||
                          '"id_address": ' || :NEW.id_address || ',' ||
                          '"id_regions": ' || :NEW.id_regions || ',' ||
                          '"id_tp_property": ' || :NEW.id_tp_property || ',' ||
                          '"company_name": "' || :NEW.company_name || '",' ||
                          '"cnpj": ' || :NEW.cnpj || ',' ||
                          '"email_company": "' || :NEW.email_company || '",' ||
                          '"phone_company": "' || :NEW.phone_company || '"' ||
                          '}';
    ELSIF UPDATING THEN
        v_operation := 'UPDATE';
        v_affected_row := '{' ||
                          '"id_company": ' || :NEW.id_company || ',' ||
                          '"id_address": ' || :NEW.id_address || ',' ||
                          '"id_regions": ' || :NEW.id_regions || ',' ||
                          '"id_tp_property": ' || :NEW.id_tp_property || ',' ||
                          '"company_name": "' || :NEW.company_name || '",' ||
                          '"cnpj": ' || :NEW.cnpj || ',' ||
                          '"email_company": "' || :NEW.email_company || '",' ||
                          '"phone_company": "' || :NEW.phone_company || '"' ||
                          '}';
    ELSIF DELETING THEN
        v_operation := 'DELETE';
        v_affected_row := '{' ||
                          '"id_company": ' || :OLD.id_company || ',' ||
                          '"id_address": ' || :OLD.id_address || ',' ||
                          '"id_regions": ' || :OLD.id_regions || ',' ||
                          '"id_tp_property": ' || :OLD.id_tp_property || ',' ||
                          '"company_name": "' || :OLD.company_name || '",' ||
                          '"cnpj": ' || :OLD.cnpj || ',' ||
                          '"email_company": "' || :OLD.email_company || '",' ||
                          '"phone_company": "' || :OLD.phone_company || '"' ||
                          '}';
    END IF;

    INSERT INTO audit_log (audit_id, table_name, operation, affected_row)
    VALUES (
        SQ_audit_log.NEXTVAL,
        't_company',
        v_operation,
        v_affected_row
    );
END trg_audit_t_company;
/

-------------------------------------------------------------------------
--Trigger para t_services

CREATE OR REPLACE TRIGGER trg_audit_t_services
AFTER INSERT OR UPDATE OR DELETE ON t_services
FOR EACH ROW
DECLARE
    v_affected_row CLOB;
    v_operation VARCHAR2(10);
BEGIN
    IF INSERTING THEN
        v_operation := 'INSERT';
        v_affected_row := '{' ||
                          '"id_service": ' || :NEW.id_service || ',' ||
                          '"id_client": ' || :NEW.id_client || ',' ||
                          '"id_company": ' || :NEW.id_company || ',' ||
                          '"id_tp_service": ' || :NEW.id_tp_service || ',' ||
                          '"type_user": "' || :NEW.type_user || '"' ||
                          '}';
    ELSIF UPDATING THEN
        v_operation := 'UPDATE';
        v_affected_row := '{' ||
                          '"id_service": ' || :NEW.id_service || ',' ||
                          '"id_client": ' || :NEW.id_client || ',' ||
                          '"id_company": ' || :NEW.id_company || ',' ||
                          '"id_tp_service": ' || :NEW.id_tp_service || ',' ||
                          '"type_user": "' || :NEW.type_user || '"' ||
                          '}';
    ELSIF DELETING THEN
        v_operation := 'DELETE';
        v_affected_row := '{' ||
                          '"id_service": ' || :OLD.id_service || ',' ||
                          '"id_client": ' || :OLD.id_client || ',' ||
                          '"id_company": ' || :OLD.id_company || ',' ||
                          '"id_tp_service": ' || :OLD.id_tp_service || ',' ||
                          '"type_user": "' || :OLD.type_user || '"' ||
                          '}';
    END IF;

    INSERT INTO audit_log (audit_id, table_name, operation, affected_row)
    VALUES (
        SQ_audit_log.NEXTVAL,
        't_services',
        v_operation,
        v_affected_row
    );
END trg_audit_t_services;
/
