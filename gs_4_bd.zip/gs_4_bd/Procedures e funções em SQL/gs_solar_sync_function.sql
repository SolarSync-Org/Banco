---------------------------------------------------------------------------------------
--Calculo de idade 

CREATE OR REPLACE FUNCTION calculate_age(p_birth_date IN DATE) RETURN NUMBER AS
    v_age NUMBER;
BEGIN
    v_age := FLOOR(MONTHS_BETWEEN(SYSDATE, p_birth_date) / 12);
    RETURN v_age;
END;
/


SELECT calculate_age(TO_DATE('1990-03-25', 'YYYY-MM-DD')) AS age FROM dual;

---------------------------------------------------------------------------------------
--Validacao de CPF

CREATE OR REPLACE FUNCTION validate_cpf(p_cpf IN NUMBER) RETURN VARCHAR2 AS
BEGIN
    IF LENGTH(TO_CHAR(p_cpf)) = 11 THEN
        RETURN 'Valid';
    ELSE
        RETURN 'Invalid';
    END IF;
END;
/


--valido =11
SELECT validate_cpf(12345678901) AS cpf_status FROM dual;

--invalido >11
SELECT validate_cpf(123345678901) AS cpf_status FROM dual;

---------------------------------------------------------------------------------------