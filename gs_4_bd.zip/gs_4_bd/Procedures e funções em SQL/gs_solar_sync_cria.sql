CREATE SEQUENCE SQ_t_address START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE SQ_t_cities START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE SQ_t_client START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE SQ_t_company START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE SQ_t_country START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE SQ_t_monthly_consumption START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE SQ_t_regions START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE SQ_t_services START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE SQ_t_state START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE SQ_t_type_property START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE SQ_t_type_service START WITH 1 INCREMENT BY 1;

--AUDITORIA
CREATE TABLE audit_log (
    audit_id       NUMBER(9) PRIMARY KEY,
    table_name     VARCHAR2(50),
    operation      VARCHAR2(10),
    affected_row   VARCHAR2(4000),
    operation_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE SEQUENCE SQ_audit_log START WITH 1 INCREMENT BY 1;


CREATE TABLE t_address (
    id_address    NUMBER(9) NOT NULL,
    id_city       NUMBER(9) NOT NULL,
    street        VARCHAR2(40) NOT NULL,
    "NUMBER"      NUMBER(10) NOT NULL,
    complement    VARCHAR2(20) NOT NULL,
    neighborhood  VARCHAR2(20) NOT NULL,
    zip_code      VARCHAR2(9) NOT NULL
);

COMMENT ON COLUMN t_address.id_address IS
    'Esse atributo ir� receber a chave prim�ria do endere�o. Esse n�mero � sequencial e gerado automaticamente pelo sistema. Seu conte�do � obrigat�rio.';

COMMENT ON COLUMN t_address.id_city IS
    'Esse atributo ir� receber a chave prim�ria da cidade. Esse n�mero � sequencial e gerado automaticamente pelo sistema. Seu conte�do � obrigat�rio.';

COMMENT ON COLUMN t_address.street IS
    'Este atributo ir� receber o nome da rua. Seu conteudo � obrigat�rio.
';

COMMENT ON COLUMN t_address."NUMBER" IS
    'Este atributo ir� receber o n�mero do endere�o. Seu conteudo � obrigat�rio.
';

COMMENT ON COLUMN t_address.complement IS
    'Este atributo ir� receber o complemento do endere�o. Seu conteudo � obrigat�rio.
';

COMMENT ON COLUMN t_address.neighborhood IS
    'Este atributo ir� receber o bairro da rua. Seu conteudo � obrigat�rio.
';

COMMENT ON COLUMN t_address.zip_code IS
    'Este atributo ir� receber o CEP do endere�o. Seu conte�do � obrigat�rio.
';

CREATE UNIQUE INDEX t_address__idx ON
    t_address (
        id_city
    ASC );

ALTER TABLE t_address ADD CONSTRAINT t_address_pk PRIMARY KEY ( id_address );

CREATE TABLE t_cities (
    id_city    NUMBER(9) NOT NULL,
    id_state   NUMBER(9) NOT NULL,
    city_name  VARCHAR2(30) NOT NULL
);

COMMENT ON COLUMN t_cities.id_city IS
    'Esse atributo ir� receber a chave prim�ria da cidade. Esse n�mero � sequencial e gerado automaticamente pelo sistema. Seu conte�do � obrigat�rio.';

COMMENT ON COLUMN t_cities.id_state IS
    'Esse atributo ir� receber a chave prim�ria do estado. Esse n�mero � sequencial e gerado automaticamente pelo sistema. Seu conte�do � obrigat�rio.';

COMMENT ON COLUMN t_cities.city_name IS
    'Este atributo ir� receber o nome da cidade. Seu conteudo � obrigat�rio.
';

CREATE UNIQUE INDEX t_cities__idx ON
    t_cities (
        id_state
    ASC );

ALTER TABLE t_cities ADD CONSTRAINT t_cities_pk PRIMARY KEY ( id_city );

CREATE TABLE t_client (
    id_client       NUMBER(9) NOT NULL,
    id_address      NUMBER(9) NOT NULL,
    id_tp_property  NUMBER(9) NOT NULL,
    client_name     VARCHAR2(30) NOT NULL,
    birth_date      DATE NOT NULL,
    cpf             NUMBER(11) NOT NULL,
    email_client    VARCHAR2(40) NOT NULL,
    phone_client    VARCHAR2(14) NOT NULL,
    rent            CHAR(1) NOT NULL
);

COMMENT ON COLUMN t_client.id_client IS
    'Esse atributo ir� receber a chave prim�ria do cliente. Esse n�mero � sequencial e gerado automaticamente pelo sistema. Seu conte�do � obrigat�rio.';

COMMENT ON COLUMN t_client.id_address IS
    'Esse atributo ir� receber a chave prim�ria do endere�o. Esse n�mero � sequencial e gerado automaticamente pelo sistema. Seu conte�do � obrigat�rio.';

COMMENT ON COLUMN t_client.id_tp_property IS
    'Esse atributo ir� receber a chave prim�ria do tipo de imovel. Esse n�mero � sequencial e gerado automaticamente pelo sistema. Seu conte�do � obrigat�rio.';

COMMENT ON COLUMN t_client.client_name IS
    'Este atributo ir� receber o nome do cliente. Seu conteudo � obrigat�rio.';

COMMENT ON COLUMN t_client.birth_date IS
    'Este atributo ir� receber a data de anivers�rio do cliente. Seu conteudo � obrigat�rio.';

COMMENT ON COLUMN t_client.cpf IS
    'Este atributo ir� receber o cpf do cliente. Seu conteudo � obrigat�rio.';

COMMENT ON COLUMN t_client.email_client IS
    'Este atributo ir� receber o email do cliente. Seu conteudo � obrigat�rio.';

COMMENT ON COLUMN t_client.phone_client IS
    'Este atributo ir� receber o telefone do cliente. Seu conteudo � obrigat�rio.';

COMMENT ON COLUMN t_client.rent IS
    'Este atributo ir� receber True (T) ou False (F) se for aluguel ou nao. Seu conteudo � obrigat�rio.';

CREATE UNIQUE INDEX t_client__idxv1 ON
    t_client (
        id_address
    ASC );

CREATE UNIQUE INDEX t_client__idx ON
    t_client (
        id_tp_property
    ASC );

ALTER TABLE t_client ADD CONSTRAINT t_client_pk PRIMARY KEY ( id_client );

CREATE TABLE t_company (
    id_company      NUMBER(9) NOT NULL,
    id_address      NUMBER(9) NOT NULL,
    id_regions      NUMBER(9) NOT NULL,
    id_tp_property  NUMBER(9) NOT NULL,
    company_name    VARCHAR2(20) NOT NULL,
    cnpj            NUMBER(11) NOT NULL,
    email_company   VARCHAR2(40) NOT NULL,
    phone_company   VARCHAR2(14) NOT NULL
);

COMMENT ON COLUMN t_company.id_company IS
    'Esse atributo ir� receber a chave prim�ria da companhia. Esse n�mero � sequencial e gerado automaticamente pelo sistema. Seu conte�do � obrigat�rio.';

COMMENT ON COLUMN t_company.id_address IS
    'Esse atributo ir� receber a chave prim�ria do endere�o. Esse n�mero � sequencial e gerado automaticamente pelo sistema. Seu conte�do � obrigat�rio.';

COMMENT ON COLUMN t_company.id_regions IS
    'Esse atributo ir� receber a chave prim�ria da regi�o. Esse n�mero � sequencial e gerado automaticamente pelo sistema. Seu conte�do � obrigat�rio.';

COMMENT ON COLUMN t_company.id_tp_property IS
    'Esse atributo ir� receber a chave prim�ria do tipo de imovel. Esse n�mero � sequencial e gerado automaticamente pelo sistema. Seu conte�do � obrigat�rio.';

COMMENT ON COLUMN t_company.company_name IS
    'Este atributo ir� receber o nome da companhia. Seu conteudo � obrigat�rio.
';

COMMENT ON COLUMN t_company.cnpj IS
    'Este atributo ir� receber o cnpj da companhia. Seu conteudo � obrigat�rio.
';

COMMENT ON COLUMN t_company.email_company IS
    'Este atributo ir� receber o email da companhia. Seu conteudo � obrigat�rio.
';

COMMENT ON COLUMN t_company.phone_company IS
    'Este atributo ir� receber o telefone da companhia. Seu conteudo � obrigat�rio.
';

CREATE UNIQUE INDEX t_company__idxv1 ON
    t_company (
        id_address
    ASC );

CREATE UNIQUE INDEX t_company__idx ON
    t_company (
        id_regions
    ASC );

CREATE UNIQUE INDEX t_company__idxv2 ON
    t_company (
        id_tp_property
    ASC );

ALTER TABLE t_company ADD CONSTRAINT t_company_pk PRIMARY KEY ( id_company );

CREATE TABLE t_country (
    id_country    NUMBER(9) NOT NULL,
    name_country  VARCHAR2(20) NOT NULL
);

COMMENT ON COLUMN t_country.id_country IS
    'Esse atributo ir� receber a chave prim�ria do pais. Esse n�mero � sequencial e gerado automaticamente pelo sistema. Seu conte�do � obrigat�rio.';

COMMENT ON COLUMN t_country.name_country IS
    'Este atributo ir� receber o nome do pais. Seu conteudo � obrigat�rio.';

ALTER TABLE t_country ADD CONSTRAINT pais_pk PRIMARY KEY ( id_country );

CREATE TABLE t_monthly_consumption (
    id_consumption      NUMBER(9) NOT NULL,
    id_client           NUMBER(9) NOT NULL,
    energy_consumption  NUMBER(38) NOT NULL,
    month_registration  DATE NOT NULL
);

COMMENT ON COLUMN t_monthly_consumption.id_consumption IS
    'Esse atributo ir� receber a chave prim�ria do consumo. Esse n�mero � sequencial e gerado automaticamente pelo sistema. Seu conte�do � obrigat�rio.';

COMMENT ON COLUMN t_monthly_consumption.id_client IS
    'Esse atributo ir� receber a chave prim�ria do cliente. Esse n�mero � sequencial e gerado automaticamente pelo sistema. Seu conte�do � obrigat�rio.';

COMMENT ON COLUMN t_monthly_consumption.energy_consumption IS
    'Este atributo ir� receber o valor gasto da energia. Seu conteudo � obrigat�rio.
';

COMMENT ON COLUMN t_monthly_consumption.month_registration IS
    'Este atributo ir� receber o m�s do registro da conta de luz. Seu conteudo � obrigat�rio.
';

CREATE UNIQUE INDEX t_monthly__consumption__idx ON
    t_monthly_consumption (
        id_client
    ASC );

ALTER TABLE t_monthly_consumption ADD CONSTRAINT consumo_mensal_pk PRIMARY KEY ( id_consumption );

CREATE TABLE t_regions (
    id_regions     NUMBER(9) NOT NULL,
    coverage_area  VARCHAR2(40) NOT NULL
);

COMMENT ON COLUMN t_regions.coverage_area IS
    'Este atributo ir� receber a ar�a de cobertura da companhia. Seu conteudo � obrigat�rio.
';

ALTER TABLE t_regions ADD CONSTRAINT t_regions_pk PRIMARY KEY ( id_regions );

CREATE TABLE t_services (
    id_service     NUMBER(9) NOT NULL,
    id_client      NUMBER(9) NOT NULL,
    id_company     NUMBER(9) NOT NULL,
    id_tp_service  NUMBER NOT NULL,
    type_user      VARCHAR2(20) NOT NULL
);

COMMENT ON COLUMN t_services.id_service IS
    'Esse atributo ir� receber a chave prim�ria do servi�o. Esse n�mero � sequencial e gerado automaticamente pelo sistema. Seu conte�do � obrigat�rio.';

COMMENT ON COLUMN t_services.id_client IS
    'Esse atributo ir� receber a chave prim�ria do cliente. Esse n�mero � sequencial e gerado automaticamente pelo sistema. Seu conte�do � obrigat�rio.';

COMMENT ON COLUMN t_services.id_company IS
    'Esse atributo ir� receber a chave prim�ria da companhia. Esse n�mero � sequencial e gerado automaticamente pelo sistema. Seu conte�do � obrigat�rio.';

COMMENT ON COLUMN t_services.id_tp_service IS
    'Esse atributo ir� receber a chave prim�ria do tipo de imovel. Esse n�mero � sequencial e gerado automaticamente pelo sistema. Seu conte�do � obrigat�rio.';

COMMENT ON COLUMN t_services.type_user IS
    'Este atributo ir� receber se o usu�rio esta contratando um servi�o ou se ele � um prestador de servi�o. Seu conteudo � obrigat�rio.';

CREATE UNIQUE INDEX t_services__idx ON
    t_services (
        id_client
    ASC );

CREATE UNIQUE INDEX t_services__idxv1 ON
    t_services (
        id_company
    ASC );

CREATE UNIQUE INDEX t_services__idxv2 ON
    t_services (
        id_tp_service
    ASC );

ALTER TABLE t_services ADD CONSTRAINT t_services_pk PRIMARY KEY ( id_service );

CREATE TABLE t_state (
    id_state    NUMBER(9) NOT NULL,
    id_country  NUMBER(9) NOT NULL,
    name_state  VARCHAR2(20) NOT NULL
);

COMMENT ON COLUMN t_state.id_state IS
    'Esse atributo ir� receber a chave prim�ria do estado. Esse n�mero � sequencial e gerado automaticamente pelo sistema. Seu conte�do � obrigat�rio.';

COMMENT ON COLUMN t_state.id_country IS
    'Esse atributo ir� receber a chave prim�ria do pais. Esse n�mero � sequencial e gerado automaticamente pelo sistema. Seu conte�do � obrigat�rio.';

COMMENT ON COLUMN t_state.name_state IS
    'Este atributo ir� receber o nome do estado. Seu conteudo � obrigat�rio.';

CREATE UNIQUE INDEX t_state__idx ON
    t_state (
        id_country
    ASC );

ALTER TABLE t_state ADD CONSTRAINT t_estado_pk PRIMARY KEY ( id_state );

CREATE TABLE t_type_property (
    id_tp_property  NUMBER(9) NOT NULL,
    tp_residence    VARCHAR2(20) NOT NULL
);

COMMENT ON COLUMN t_type_property.id_tp_property IS
    'Esse atributo ir� receber a chave prim�ria do tipo de imovel. Esse n�mero � sequencial e gerado automaticamente pelo sistema. Seu conte�do � obrigat�rio.';

COMMENT ON COLUMN t_type_property.tp_residence IS
    'Este atributo ir� receber o tipo da residencia do cliente ou o tipo de residencia que o prestador de servi�o atua (casa, apartamento, sitio ou chacara). Seu conteudo � obrigat�rio. 
';

ALTER TABLE t_type_property ADD CONSTRAINT tp_imovel_pk PRIMARY KEY ( id_tp_property );

CREATE TABLE t_type_service (
    id_tp_service  NUMBER NOT NULL,
    solutions      VARCHAR2(30) NOT NULL
);

COMMENT ON COLUMN t_type_service.id_tp_service IS
    'Esse atributo ir� receber a chave prim�ria do tipo de servico. Esse n�mero � sequencial e gerado automaticamente pelo sistema. Seu conte�do � obrigat�rio.';

COMMENT ON COLUMN t_type_service.solutions IS
    'Este atributo ir� receber a solu��odo que o cliente deseja ou da companhia (alugar, vender ou manuten��o). Seu conteudo � obrigat�rio.
';

ALTER TABLE t_type_service ADD CONSTRAINT tp_servico_pk PRIMARY KEY ( id_tp_service );

ALTER TABLE t_address
    ADD CONSTRAINT relation_1 FOREIGN KEY ( id_city )
        REFERENCES t_cities ( id_city );

ALTER TABLE t_client
    ADD CONSTRAINT relation_12 FOREIGN KEY ( id_tp_property )
        REFERENCES t_type_property ( id_tp_property );

ALTER TABLE t_services
    ADD CONSTRAINT relation_13 FOREIGN KEY ( id_client )
        REFERENCES t_client ( id_client );

ALTER TABLE t_services
    ADD CONSTRAINT relation_14 FOREIGN KEY ( id_company )
        REFERENCES t_company ( id_company );

ALTER TABLE t_services
    ADD CONSTRAINT relation_15 FOREIGN KEY ( id_tp_service )
        REFERENCES t_type_service ( id_tp_service );

ALTER TABLE t_company
    ADD CONSTRAINT relation_16 FOREIGN KEY ( id_regions )
        REFERENCES t_regions ( id_regions );

ALTER TABLE t_state
    ADD CONSTRAINT relation_17 FOREIGN KEY ( id_country )
        REFERENCES t_country ( id_country );

ALTER TABLE t_cities
    ADD CONSTRAINT relation_18 FOREIGN KEY ( id_state )
        REFERENCES t_state ( id_state );

ALTER TABLE t_monthly_consumption
    ADD CONSTRAINT relation_20 FOREIGN KEY ( id_client )
        REFERENCES t_client ( id_client );

ALTER TABLE t_company
    ADD CONSTRAINT relation_21 FOREIGN KEY ( id_tp_property )
        REFERENCES t_type_property ( id_tp_property );

ALTER TABLE t_client
    ADD CONSTRAINT relation_6 FOREIGN KEY ( id_address )
        REFERENCES t_address ( id_address );

ALTER TABLE t_company
    ADD CONSTRAINT relation_7 FOREIGN KEY ( id_address )
        REFERENCES t_address ( id_address );